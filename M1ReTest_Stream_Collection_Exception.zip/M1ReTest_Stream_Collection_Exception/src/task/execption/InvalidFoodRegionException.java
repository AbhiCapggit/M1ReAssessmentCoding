package task.execption;

public class InvalidFoodRegionException extends InvalidFoodDetailsException{

    public InvalidFoodRegionException(String message) {
        super(message);
    }
    
}
