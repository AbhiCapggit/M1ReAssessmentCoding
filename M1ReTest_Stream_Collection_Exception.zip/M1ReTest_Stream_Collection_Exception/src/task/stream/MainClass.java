package task.stream;

import java.util.Map; 

import entity.Food;
import entity.Type;

/* You cannot change any code*/
public class MainClass {

	public static void main(String[] args) {
		
		BusinessOperation bo = new BusinessOperation(); //An instance of the BusinessOperation class is created. This class contains the methods that perform various operations on a list of Food objects.
		
		System.out.println("Avg cost of Veg Food :- "+bo.avgCostByCategory(Type.VEG));
		System.out.println("Avg cost of Non-Veg Food :- "+bo.avgCostByCategory(Type.NON_VEG));
		System.out.println("\n\n--------------------------\n\n");
		
		for (Food food : bo.increaseCostOfFoodByRegion("Indian")) {
			System.out.println(food);
		}
		
		System.out.println("\n\n--------------------------\n\n");
		
		for (Map.Entry<String, Integer> entry :bo.getFoodDetails().entrySet()) {
			System.out.println(entry.getKey()+" - "+entry.getValue());
			
			//This loop calls the getFoodDetails method from the BusinessOperation class to retrieve a Map where keys are food item names, and values are the total counts of reviews for each food item. It then prints each food item along with its review count.

//This MainClass demonstrates how to use the methods from the BusinessOperation class to perform operations on a list of food items, such as calculating average costs, updating costs of items by region, and retrieving review counts for each food item.





		}
	}
}

